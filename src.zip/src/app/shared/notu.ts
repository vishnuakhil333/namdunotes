export interface Notu {
   $key: string;
   title: string;
   description: string;
   // email: string
   // mobileNumber: Number;
}
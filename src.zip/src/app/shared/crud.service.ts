import { Injectable } from '@angular/core';
import { Notu } from './notu';  // Student data type interface class
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';  // Firebase modules for Database, Data list and Single object

@Injectable({
  providedIn: 'root'
})

export class CrudService {
  notusRef: AngularFireList<any>;    // Reference to Student data list, its an Observable
  notuRef: AngularFireObject<any>;   // Reference to Student object, its an Observable too
  
  // Inject AngularFireDatabase Dependency in Constructor
  constructor(private db: AngularFirestore) { }

  // Create Student
  AddStudent(notu: Notu) {
    // this.notusRef.push({
    //   title: notu.title,
    //   description: notu.description,
    //   // email: student.email,
    //   // mobileNumber: student.mobileNumber
    // })

    // For CloudFirestore
    return this.db.collection('notus-list').add(notu);

  }

  // Fetch Single Student Object
  GetStudent(id: string) {
    return this.db.collection('notus-list/' + id).get()

  }

  // Fetch Students List
  GetStudentsList() {
    // this.notusRef = this.db.list('notus-list');
    // return this.notusRef;
    return this.db.collection('notus-list').snapshotChanges();
  }

  // Update Student Object
  UpdateStudent(notu) {
    // this.notuRef.update({
    //   title: notu.title,
    //   description: notu.description,
    //   // email: student.email,
    //   // mobileNumber: student.mobileNumber
    // })
    return this.db.doc('notus-list/').update(notu)
  }  

  // Delete Student Object
  DeleteStudent(id: string) { 
    // this.notuRef = this.db.object('notus-list/'+id);
    // this.notuRef.remove();
    return this.db.doc('notus-list/' + id).delete()
  }
  
}
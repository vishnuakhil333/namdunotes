export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBbcbexXbfQnsN5y773H0ZeEgUQ-As1s-g",
    authDomain: "angularcrud-6e8d4.firebaseapp.com",
    databaseURL: "https://angularcrud-6e8d4.firebaseio.com",
    projectId: "angularcrud-6e8d4",
    storageBucket: "angularcrud-6e8d4.appspot.com",
    messagingSenderId: "394168458454",
    appId: "1:394168458454:web:747ec30b195105ee6bbd77",
    measurementId: "G-TRG2DZ4CW2"
  }
};